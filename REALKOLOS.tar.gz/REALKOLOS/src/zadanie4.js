class Log {
    write() {
        
    }
}